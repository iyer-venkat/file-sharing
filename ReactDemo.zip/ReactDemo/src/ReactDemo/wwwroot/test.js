﻿//alert(document.body);

window.onload = function () {
    //alert(1);
    ////document.body.addEventListener('onload', function () {
    //    alert("Hi!");

        var HelloMessage = React.createClass({
            displayName: 'HelloMessage',
            render: function render() {
                return React.createElement('div', null, 'Hello ', this.props.name);
            }
        });
        ReactDOM.render(React.createElement(HelloMessage, { name: 'John' }), document.getElementById('app'));
    //});

    document.body.addEventListener('click', function () {
        console.log("Hi1!");
    },false);

    //alert(1);
    //alert("Hi!");

};