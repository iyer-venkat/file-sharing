﻿import React from 'react';
import {CommentForm} from './CommentForm';
import {CommentList} from './CommentList';
import {CommentForm1} from './Test.jsx';

export class CommentBox extends React.Component{
    constructor(props) {
        super(props);
        this.state = { data: [], wait: "block" };
    }

    componentWillMount() {
        var url=this.props.url;

        //var xhr = new XMLHttpRequest();
        //xhr.open('get', url, true);
        //xhr.onload = function() {
        //    var data = JSON.parse(xhr.responseText);
        //    this.setState({ data: data, wait: "none" });
        //}.bind(this);
        //xhr.send();

        //this.httpGet(url)
        //.then(
        //    function (value) {
        //        console.log('Contents: ' + value);
        //    },
        //    function (reason) {
        //        console.error('Something went wrong', reason);
        //    });

        var self = this;
        var myHeaders = new Headers();
        var options = { method: 'POST',
            headers: myHeaders,
            mode: 'cors',
            cache: 'default' };

        fetch('/api/values', options).then(function(response) {
            if(response.ok)
                return response.json();
            throw new Error('Network response was not ok.');
        }).then(function(response){
            console.log(response);
            self.setState({ data: response, wait: "none" });
        }).catch(function(error) {
            console.log('There has been a problem with your fetch operation: ', error.message);
        });

        /*
        const fetchAsyncA = async () => await (await fetch('https://api.github.com')).json();
        */
    }

    //httpGet(url) {
    //    return new Promise(
    //        function (resolve, reject) {
    //            var request = new XMLHttpRequest();
    //            request.onreadystatechange = function () {
    //                if (this.status === 200) {
    //                    // Success
    //                    resolve(this.response);
    //                } else {
    //                    // Something went wrong (404 etc.)
    //                    reject(new Error(this.statusText));
    //                }
    //            }
    //            request.onerror = function () {
    //                reject(new Error(
    //                    'XMLHttpRequest Error: '+this.statusText));
    //            };
    //            request.open('GET', url);
    //            request.send();    
    //        });
    //}

    render() {
        var divStyle = {
            backgroundColor: 'lightgray',
            height: '100%',
            width: '100%',
            position: 'absolute',
            opacity: 0.7,
            textAlign: 'center',
            verticalAlign: 'text-bottom',
            display: this.state.wait
        };
        return <div className="commentBox">
            <div style={divStyle}>Please wait...</div>
            Hello, world! I am a CommentBox. This is awesome!
            <CommentList data={this.state.data} />
            <CommentForm />
            <CommentForm1 />
          </div>
    }
}