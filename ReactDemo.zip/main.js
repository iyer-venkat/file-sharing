﻿//https://github.com/arnemahl/react-raphael-webpack-es6
//https://www.npmjs.com/package/react-raphael

//https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs
//https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/development_environment

/* Hello, World! program in node.js */
console.log("Hello, World!");
console.log("-------------");

//######################## File Reading #########################
//https://www.tutorialspoint.com/nodejs/nodejs_file_system.htm
var fs = require("fs");
try{
	var data = fs.readFileSync("c:\\venkat\\input.txt");
	console.log(data.toString());
}
catch(e){
	console.log("Sync Reading=>"+e);
}
console.log("-------------");

fs.readFile("c:\\venkat\\input.txt", function (err, data) {
   if (err) return console.error(err);
   console.log(data.toString());
   console.log("-------------");
});
console.log("-------------");


//######################## Event Emitter #########################
// Import events module
var events = require('events');

// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();

// Create an event handler as follows
var connectHandler = function connected() {
   console.log('connection successful.');
  
   // Fire the data_received event 
   eventEmitter.emit('data_received');
}

// Bind the connection event with the handler
eventEmitter.on('connection', connectHandler);
 
// Bind the data_received event with the anonymous function
eventEmitter.on('data_received', function(){
   console.log('data received successfully.');
});

// Fire the connection event 
eventEmitter.emit('connection');

console.log("-------------");

//######################## 
var events = require('events');
var eventEmitter = new events.EventEmitter();

// listener #1
var listner1 = function listner1() {
   console.log('listner1 executed.');
}

// listener #2
var listner2 = function listner2() {
  console.log('listner2 executed.');
}

// Bind the connection event with the listner1 function
eventEmitter.addListener('connection', listner1);

// Bind the connection event with the listner2 function
eventEmitter.on('connection', listner2);

var eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'connection');
console.log(eventListeners + " Listner(s) listening to connection event");

// Fire the connection event 
eventEmitter.emit('connection');

// Remove the binding of listner1 function
eventEmitter.removeListener('connection', listner1);
console.log("Listner1 will not listen now.");

// Fire the connection event 
eventEmitter.emit('connection');

eventListeners = require('events').EventEmitter.listenerCount(eventEmitter,'connection');
console.log(eventListeners + " Listner(s) listening to connection event");

console.log("-------------");


//######################## Buffer #########################
//https://www.tutorialspoint.com/nodejs/nodejs_buffers.htm
/*
Writing to Buffers
Syntax: Following is the syntax of the method to write into a Node Buffer −
	buf.write(string[, offset][, length][, encoding])
Parameters: Here is the description of the parameters used −
	string − This is the string data to be written to buffer.
	offset − This is the index of the buffer to start writing at. Default value is 0.
	length − This is the number of bytes to write. Defaults to buffer.length.
	encoding − Encoding to use. 'utf8' is the default encoding.
*/
var buf = new Buffer(15);
len = buf.write("Simply Easy Learning");

console.log("Octets written : "+  len);

console.log(buf.toString());
console.log("-------------");


//######################## Compression / Decompression #############################
//https://www.tutorialspoint.com/nodejs/nodejs_streams.htm
/*
try{
var zlib = require('zlib');

// Compress the file input.txt to input.txt.gz
fs.createReadStream('input.txt')
   .pipe(zlib.createGzip())
   .pipe(fs.createWriteStream('input.txt.gz'));
  
console.log("File Compressed.");
console.log("-------------");

// Decompress the file input.txt.gz to input.txt
fs.createReadStream('input.txt.gz')
   .pipe(zlib.createGunzip())
   .pipe(fs.createWriteStream('input.txt'));
  
console.log("File Decompressed.");
console.log("-------------");
}
catch(e){
	console.log("Compression error=>"+e);
}
*/

//######################## Express #########################
//https://www.tutorialspoint.com/nodejs/nodejs_web_module.htm
//https://www.tutorialspoint.com/nodejs/nodejs_express_framework.htm
//https://www.tutorialspoint.com/nodejs/nodejs_restful_api.htm

//https://zellwk.com/blog/crud-express-mongodb/
//https://docs.mongodb.com/
//https://www.tutorialspoint.com/mongodb/

var http = require("http");

http.createServer(function (request, response) {

   // Send the HTTP header 
   // HTTP Status: 200 : OK
   // Content Type: text/plain
   response.writeHead(200, {'Content-Type': 'text/plain'});
   
   // Send the response body as "Hello World"
   response.end('Hello World\n');
}).listen(8081);

// Console will print the message
console.log('Server running at http://127.0.0.1:8081/');



var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var pug = require('pug');
var path = require('path');

// Create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.engine('pug', require('pug').__express);
app.set('views', path.join(__dirname, ''));
app.set("view engine", "pug");

app.use(express.static('wwwroot'));

app.get('/person', function (req, res) {
    res.render('wwwroot/person');
});

app.get('/index.htm', function (req, res) {
    res.sendFile(__dirname + "/" + "index.html");
})

app.get('/process_get', function (req, res) {
    // Prepare output in JSON format
    response = {
        first_name: req.query.first_name,
        last_name: req.query.last_name
    };
    console.log(response);
    res.end(JSON.stringify(response));
})

app.post('/process_post', urlencodedParser, function (req, res) {
    // Prepare output in JSON format
    response = {
        first_name: req.body.first_name,
        last_name: req.body.last_name
    };
    console.log(response);
    res.end(JSON.stringify(response));
})

// This responds with "Hello World" on the homepage
app.get('/', function (req, res) {
    console.log("Got a GET request for the homepage");
    //res.send('Hello GET');
    res.sendFile(__dirname + "/wwwroot/index.html");
})

// This responds a POST request for the homepage
app.post('/', function (req, res) {
    console.log("Got a POST request for the homepage");
    //res.send('Hello POST');
    res.sendFile(__dirname + "/wwwroot/index.html");
})

// This responds a DELETE request for the /del_user page.
app.delete('/del_user', function (req, res) {
    console.log("Got a DELETE request for /del_user");
    res.send('Hello DELETE');
})

// This responds a GET request for the /list_user page.
app.get('/list_user', function (req, res) {
    console.log("Got a GET request for /list_user");
    res.send('Page Listing');
})

// This responds a GET request for abcd, abxcd, ab123cd, and so on
app.get('/ab*cd', function (req, res) {
    console.log("Got a GET request for /ab*cd");
    res.send('Page Pattern Match');
})

app.post('/process_post', urlencodedParser, function (req, res) {
    // Prepare output in JSON format
    response = {
        first_name: req.body.first_name,
        last_name: req.body.last_name
    };
    console.log(response);
    res.end(JSON.stringify(response));
})

app.post('/api/values', urlencodedParser, function (req, res) {
    // Prepare output in JSON format
    response = [{
                    Id: 1,
                    Author: "Daniel Lo",
                    Text: "<em>document.onload=function(){alert('Hi');}</em>"
                },
                {
                    Id: 2,
                    Author: "Ethan Hunt",
                    Text: "This is one comment<script>alert('Hi!')</script>"
                },
                {
                    Id: 3,
                    Author: "Jordan Walker",
                    Text: "This is *another* comment"
                }];
    console.log(response);
    res.end(JSON.stringify(response));
})


var server = app.listen(8082, function () {
    try {
        var host = "127.0.0.1"	//server.address().address
        var port = server.address().port

        console.log("Example app listening at http://%s:%s", host, port)
    }
    catch (e) {
        console.log("ERROR::" + e)
    }
})
