﻿import React from 'react';
//import {Remarkable} from 'remarkable';

export class Comment extends React.Component{
    createMarkup(param) { return {__html: param}; };
    render() {
        //alert(this.props.author+"::"+this.props.children);
        return (
            <div className="comment">
                <h2 className="commentAuthor">{this.props.author}</h2>
                <span dangerouslySetInnerHTML={this.createMarkup(this.props.children)} />
        </div>);
    }
}