﻿import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter, BrowserRouter, Switch, Redirect, Route, NavLink as Link, browserHistory  } from 'react-router-dom';
import style from "./css/site.css";

import {CommentBox} from "./components/CommentBox"

class App extends React.Component {
    constructor(){
        super();
    }

    render(){
        var Menu=[{to: "/home", text: "Home"}, {to: "/about", text: "About"}, {to: "/ConTact", text: "Contact" }, {to: "", text: "What's this?!!", disabled: true}];
        return (
            <div>
                <Nav menu={Menu} />
                <Main />
            </div>
            );
    }
}
//App.contextTypes = {
//    router: React.PropTypes.object
//};

class Nav extends React.Component{
    //constructor({param}){
    constructor(){
        super();
        //this.param = param;
        this.state={navLink: 'nav-link', activeIndex: 0};
        this.handleMenuClick=this.handleMenuClick.bind(this);
    }

    handleMenuClick(e) {
        var index = e.target.getAttribute('data-key');
        if(this.state.activeIndex == index)
            e.preventDefault();
        else{
            this.setState((prevState, props)=>({activeIndex: index}));
            console.log(this.state.activeIndex);
        }
    }

    render(){
        var activeIndex = this.state.activeIndex;
        return (<header>
          <nav><ul className='nav nav-pills'>
            {
                this.props.menu.map((menu, index) => (
                    <MenuItem key={index.toString()} menu={menu} index={index} activeIndex={activeIndex} handleMenuClick={this.handleMenuClick} />
                ))
            }
        </ul></nav>
        </header>);
    }
}

//{menu, index, activeIndex, handleMenuClick}
//        <Link onClick={(props.menu.disabled)?null:props.handleMenuClick} to={{ pathname: props.menu.to, query: props.param }} className={`nav-link ${(props.menu.disabled)?'disabled':(props.activeIndex==props.index)? 'active': ''}`} data-key={props.index}>{props.menu.text}</Link>
var MenuItem = (props) => (
    <li className='nav-item'>
        <Link onClick={(props.menu.disabled)?null:props.handleMenuClick} to={{ pathname: props.menu.to, query: props.param }} className={`nav-link ${(props.menu.disabled)?'disabled':''}`} activeClassName={`${(props.menu.disabled)?'':'active'}`} data-key={props.index}>{props.menu.text}</Link>
    </li>
);
//
const Main = () => (
    <main>
        <Switch>
            <Redirect exact from="/" to="/home" />
            <Route path = '/home' component = {Home} urlParam="Venkat" />
            <Route path = '/about' component = {About} />
            <Route path = '/contact' component = {Contact} />
        </Switch>
    </main>
);

class Home extends React.Component{
    constructor(props/*,{match}*/){
        super(props);
        this.match=props.match;
        console.log(`Home => ${JSON.stringify(this.match)}`);

        this.props=props;
        this.props.Name="Venkat";
        this.props.Age=37;
        console.log(`Home => ${JSON.stringify(this.props)}`);
        this.state={show: false};
    }

        
    componentWillMount() {
        console.log('Component WILL MOUNT!')
        }

    componentDidMount() {
        console.log('Component DID MOUNT!')
        }

    componentWillReceiveProps(newProps) {    
        console.log('Component WILL RECIEVE PROPS!')
        }

    shouldComponentUpdate(newProps, newState) {
        return true;
        }

    componentWillUpdate(nextProps, nextState) {
        console.log('Component WILL UPDATE!');
        }

    componentDidUpdate(prevProps, prevState) {
        console.log('Component DID UPDATE!')
        }

    componentWillUnmount() {
        console.log('Component WILL UNMOUNT!')
        }

    componentDidMount() {
        console.log("componentDidMount()");
        setTimeout(() => this.setState({show: true}), 1);
    }

    render(){
        var Menu=[{to: '/home/', text: "Payment"}, {to: `${this.match.url}/payees`, text: "Payees"}, {to: `/home/billers`, text: "Billers" }, {to: `${this.match.url}`, text: "What's this?!!", disabled: true}];

        console.dir("render()=>"+JSON.stringify(this.props));
        return (
            <section className={`red-border ${(this.state.show)?'':'open'}`}>
                <h2>Home</h2>
                <Test {...this.props} />
                {this.props.location.search.indexOf("true") > -1=="true" ? <button>This is a text</button>: null} <br />
                <Nav menu={Menu} />
		<Route exact path="/home/" component = {Payment} />
		<Route path = '/home/payees' render={() => { return (<Payee {...this.props} from="Home" />);}} />
		<Route path = '/home/billers' component = {Biller} />                
            </section>
        )
    }
}

export class Payee extends React.Component {
    constructor(props){
        super(props);
        this.props=props;
        console.log(`Payee => ${JSON.stringify(this.props)}`);
    }
    render() {
        return (
            <div>
                <h4>Payee...</h4>
                <h6>{this.props.from}</h6>
                <h6>{this.props.children}</h6>
           </div>
        );
    }
}
const Payment = () => ( <h3>Payment</h3> );
//const Payee = () => ( <h3>Payee</h3> );
const Biller = () => ( <h3>Biller</h3> );
const Test = (props) => ( <h3>{props.Name}</h3> );

class About extends React.Component{
    constructor({match}){
        super();
        this.match=match;
        console.log(this.props);
        console.log(this.match);
    }
    render(){
        var Menu=[{to: `${this.match.url}`, text: "Payment"}, {to: `${this.match.url}/payees`, text: "Payees"}, {to: `${this.match.url}/billers`, text: "Billers" }, {to: `${this.match.url}`, text: "What's this?!!", disabled: true}];
        return (
            <section>
                <h2>About</h2>
        {this.props.location.query=="true" ? <button>This is a text</button>: null} <br />
                <Nav menu={Menu} />
                <Route exact path = '/about/' component = {Payment} />
                <Route path = '/about/payees' component = {Payee} />
                <Route path = '/about/billers' component = {Biller} />
            </section>
        )
    }
}

class Contact extends React.Component{
    render(){
        return <div><h2>Contact</h2><CommentBox url="/api/values" /></div>
    }
}

ReactDOM.render((<HashRouter>
        <App />
    </HashRouter>), document.getElementById('app'));

////Below code is to prove that inheritance works in React, although defeats the purpose of Composition & Web-Components
//class T1 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T1=>${JSON.stringify(this.props)}`);
//    }
//    render(){
//        return <div><h2>T1{this.props.name}</h2></div>
//    }
//}
//class T2 extends T1{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T2=>${JSON.stringify(this.props)}`);
//    }
//    render(){
//        return <div>{super.render()}<h2>T2{this.props.name}</h2></div>;
//    }
//}
//ReactDOM.render((<HashRouter>
//        <T2 name="Venkat" />
//    </HashRouter>), document.getElementById('app'));

////Below code is for props.children to render child components
//class T1 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T1=>${JSON.stringify(this.props)}`);
//}
//    render(){
//        return <div><h2>T1{this.props.name}</h2><h3>{this.props.children}</h3></div>
//}
//}
//class T2 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T2=>${JSON.stringify(this.props)}`);
//}
//    render(){
//        return <div><h2>T2{this.props.name}</h2></div>;
//}
//}
//ReactDOM.render((<HashRouter>
//        <T1 name="Venkat"><T2 name="Iyer" /></T1>
//    </HashRouter>), document.getElementById('app'));