﻿import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Switch, Route, Link, browserHistory  } from 'react-router-dom';
import { ButtonGroup, Button, DropdownButton, MenuItem, Dropdown, Toggle, Menu, Table } from 'react-bootstrap';
import style from "./css/site.css";

//import history from './components/history';

//import {Spinner} from 'spin.js';
import ReactSpinner from 'react-spinjs';

const Main = () => (
    <main>
        <Switch>
            <Route exact path = "/" component = {Home} />
            <Route path = "/about" component = {About} />
            <Route path = "/contact" component = {Contact} />
        </Switch>
    </main>
);
const Header = ({param}) => (
    <div>
    <p>This is param => {param}</p>
        <header>
            <nav>
                <ul>
                    <li><Link to = "/">Home</Link></li>
                    <li><Link to = {`/about?show=${param}`}>About</Link></li>
                    <li><Link to = "/ConTact">Contact</Link></li>
                    <li><Link to = "/about/child1">Payments</Link></li>
                    <li><foo-bar>What's this?!!</foo-bar></li>
                </ul>
                <Main />
            </nav>
        </header>
    </div>
);

class App extends React.Component {
    constructor(){
        super();
        this.navigateToAbout=this.navigateToAbout.bind(this);
        this.handleClick=this.handleClick.bind(this);
        this.state={isLoading: false, wait: "none"};
                    }

    navigateToAbout(e){
        e.preventDefault();
        //this.props.history.push('/about');
        console.log(this.context.router);
        this.context.router.history.push(`/about?show=${this.state.isLoading}`);
    }

    handleClick(e) {
        alert('Hello ' + e.target.dataset.message);
        this.setState({isLoading: true, wait: "block"});

        // This probably where you would have an `ajax` call
        setTimeout(() => {
            // Completed of async action, set loading state back
            this.setState({isLoading: false, wait: "none"});
        }, 5000);
    }

    render() {
        var divStyle = {
            backgroundColor: 'lightgray',
            height: '100%',
            width: '50%',
            left: '20%',
            position: 'absolute',
            zIndex: 100,
            opacity: 0.7,
            textAlign: 'center',
            verticalAlign: 'text-bottom',
            display: this.state.wait
        };
        var spinnerOptions = {
            lines: 13, // The number of lines to draw
            length: 0, // The length of each line
            width: 5, // The line thickness
            radius: 59, // The radius of the inner circle
            scale: 1, // Scales overall size of the spinner
            corners: 1, // Corner roundness (0..1)
            color: '#fff', // #rgb or #rrggbb or array of colors
            opacity: 0.2, // Opacity of the lines
            rotate: 0, // The rotation offset
            direction: 1, // 1: clockwise, -1: counterclockwise
            speed: 0.9, // Rounds per second
            trail: 26, // Afterglow percentage
            fps: 20, // Frames per second when using setTimeout() as a fallback in IE 9
            zIndex: 2e9, // The z-index (defaults to 2000000000)
            className: 'spinner', // The CSS class to assign to the spinner
            top: '49%', // Top position relative to parent
            left: '50%', // Left position relative to parent
            shadow: false, // Whether to render a shadow
            position: 'absolute' // Element positioning
        };

        var items = [
	{ "href":"http://www.facebook.com", "image":"url(./images/social/facebook.png)"}, 
	{ "href":"http://www.reddit.com", "image":"url(./images/social/reddit.png)"}, 
	{ "href":"http://www.flickr.com", "image":"url(./images/social/flickr.png)"}, 
	{ "href":"http://www.google.com", "image":"url(./images/social/googleplus.png)"}, 
	{ "href":"http://www.linkedin.com", "image":"url(./images/social/linkedin.png)"}, 
	{ "href":"http://www.twitter.com", "image":"url(./images/social/twitter.png)"}
        ];

        var center = {
            "image":"url(./images/social/share.png)"
        };
        //<RadialMenu items={items} center={center} radius="200" />

        //var target = document.getElementById('foo');
        //var spinner = new Spinner(opts).spin(target);

        return (
            <div>
            <Table bordered striped condensed hover>
                <thead><th>Name</th><th>Age</th></thead>
                <tbody><tr><td>Venkat</td><td>36</td></tr><tr><td>Mona</td><td>37</td></tr></tbody>
            </Table>
                <div id="exTab1" class="container">	
                    <ul  class="nav nav-pills">
			            <li class="active"><a  href="#1a" data-toggle="tab">Overview</a></li>
			            <li><a href="#2a" data-toggle="tab">Using nav-pills</a></li>
			            <li><a href="#3a" data-toggle="tab">Applying clearfix</a></li>
  		                <li><a href="#4a" data-toggle="tab">Background color</a></li>
		            </ul>
                    <div class="tab-content clearfix">
			            <div class="tab-pane active" id="1a">
                            <h3>Content's background color is the same for the tab</h3>
				        </div>
				        <div class="tab-pane" id="2a">
                            <h3>We use the class nav-pills instead of nav-tabs which automatically creates a background color for the tab</h3>
				        </div>
                        <div class="tab-pane" id="3a">
                            <h3>We applied clearfix to the tab-content to rid of the gap between the tab and the content</h3>
				        </div>
                        <div class="tab-pane" id="4a">
                            <h3>We use css to change the background color of the content to be equal to the tab</h3>
				        </div>
			        </div>
                </div>

                <div style={divStyle}><ReactSpinner config={spinnerOptions} />Please wait...</div>
                <Button bsStyle="primary" data-message="World!" disabled={this.state.isLoading} onClick={!this.state.isLoading ? this.handleClick : null}>
                {this.state.isLoading ? 'Loading...' : 'Loading state'}
                </Button>
                <ButtonGroup>
                    <Button bsStyle="primary" active onClick={this.navigateToAbout}>Primary button</Button>
                    <Button>1</Button>
                    <Button>2</Button>
                    <DropdownButton title="Dropdown" id="bg-nested-dropdown">
                      <MenuItem eventKey="1">Dropdown link</MenuItem>
                      <MenuItem eventKey="2">Dropdown link</MenuItem>
                    </DropdownButton>
                    <Dropdown id="dropdown-custom-2">
                        <Button bsStyle="info">mix it up style-wise</Button>
                        <Dropdown.Toggle bsStyle="success"/>
                        <Dropdown.Menu className="super-colors">
                            <MenuItem eventKey="1">Action</MenuItem>
                            <MenuItem eventKey="2">Another action</MenuItem>
                            <MenuItem eventKey="3" active>Active Item</MenuItem>
                            <MenuItem divider />
                            <MenuItem eventKey="4">Separated link</MenuItem>
                        </Dropdown.Menu>
                    </Dropdown>
                </ButtonGroup>
                <h2 className={style.title}>This is from CSS Module!</h2>
                <Venkat param={this.state.isLoading.toString()} loadData={this.handleClick} />
                <Header param={this.state.isLoading.toString()} />
                <Main />
            </div>
       )
    }
}
App.contextTypes = {
    router: React.PropTypes.object
};

export class Home extends React.Component {
    render() {
        return (
           <div>
              <div className='loading_spinner-wrap'>
                <svg className='loading_spinner' width='60' height='20' viewBox='0 0 60 20' xmlns='http://www.w3.org/2000/svg'>
                  <circle cx='7' cy='15' r='4' />
                  <circle cx='30' cy='15' r='4' />
                  <circle cx='53' cy='15' r='4' />
                </svg>
              </div>
              <h1>Home...</h1>
           </div>
       )
   }
}

export class About extends React.Component {
    constructor({match},props){
        super(props);
        this.match=match;
        this.props=props;
        console.log(this.props);
    }
    render() {
        return (
            <div>
                <h1>About...</h1>
                {this.props.location.search.indexOf("true") > -1 ? <button>This is a button from QueryString</button>: null} <br />
                <Link to={`${this.match.url}/child1`}>Rendering with React</Link>
                <Route path={`${this.match.url}/child1`} component={Child1}/>
           </div>
        );
    }
}

export class Child1 extends React.Component {
    render() {
        return (
            <div>
                <h4>Child 1...</h4>
           </div>
        );
    }
}

export class Contact extends React.Component {
    render() {
        return (
           <div>
              <h1>Contact...</h1>
           </div>
       )
   }
}

export class Venkat extends React.Component {
    handleClick(e) {
        alert(this.props);
        console.log(this.props);
    }

    render() {
        return (
           <div>
            {this.props.param}
            <button onClick={this.props.loadData}>This is a text</button>
           </div>
       )
   }
}

ReactDOM.render((
    <BrowserRouter history = {browserHistory}>
        <App />
    </BrowserRouter>
    /*
   <BrowserRouter history = {browserHistory}>
      <Route path = "/" component = {App}>
         <IndexRoute component = {Home} />
         <Route path = "home" component = {Home} />
         <Route path = "about" component = {About} />
         <Route path = "contact" component = {Contact} />
      </Route>
   </BrowserRouter>
   */
), document.getElementById('app'));
