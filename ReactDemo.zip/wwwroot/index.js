﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';

//import { CommentBox } from './components/CommentBox';

/*state change causes repaint of the component; so does forceUpdate(): which is called on React.Component(base) class*/
class App extends React.Component {
    constructor() {
        super();
		
        this.state = {
            data: [],
            divStyle: {color: 'blue'},
            number: 0
        };
	
        this.setStateHandler = this.setStateHandler.bind(this);
        this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
        this.findDomNodeHandler = this.findDomNodeHandler.bind(this);
        this.setNewNumber = this.setNewNumber.bind(this);
        //this.updateState = this.updateState.bind(this);
    };

    //updateState(e) {
    //    this.setState({data: e.target.value});
    //}

    setNewNumber() {
        this.setState({number: this.state.number + 1});
    }

    forceUpdateHandler() {
        this.forceUpdate();
    };

    setStateHandler() {
        var item = "setState..."
        var myArray = this.state.data;
        myArray.push(item)
        this.setState({data: myArray})
    };

    findDomNodeHandler() {
        var myDiv = document.getElementById('myDiv');
        var r = Math.floor(Math.random() * 255);
        var g = Math.floor(Math.random() * 255);
        var b = Math.floor(Math.random() * 255);
        var col = "rgb(" + r + "," + g + "," + b + ")";
        this.setState({ divStyle: {color: col} });
        //ReactDOM.findDOMNode(myDiv).style.color = col;  //'green';
        //ReactDOM.findDOMNode(this.refs.myInput).focus();  /*ref="myInput"*/
    }

    render() {
        //return <CommentBox url="/api/values" />;
        return (
            <div>
                <button onClick = {this.setStateHandler}>SET STATE</button>
                <h4>State Array: {this.state.data}</h4>
                <button onClick = {this.forceUpdateHandler}>FORCE UPDATE</button>
                <h4>Random number: {Math.random()}</h4>
                <button onClick = {this.findDomNodeHandler}>FIND DOM NODE</button>
                <div id="myDiv" style={this.state.divStyle}><b>NODE</b></div>
                <button onClick = {this.setNewNumber}>INCREMENT</button>
                <hr />
                <Content myNumber = {this.state.number}></Content>
                {/*<Content myDataProp = {this.state.data} updateStateProp = {this.updateState}></Content>*/}
            </div>
        );
    }
}


class Content extends React.Component {
    constructor() {
        super();
		
        this.state = {
            data: "",
            invalid: false
        };

        this.updateState = this.updateState.bind(this);
        this.validate = this.validate.bind(this);         
    };

    updateState(e) {
        this.setState({data: e.target.value});
    }
    validate(e) {
        this.setState({invalid: this.state.data!=""?false:true});
    }

    componentWillMount() {
        console.log('Component WILL MOUNT!')
    }

    componentDidMount() {
        console.log('Component DID MOUNT!')
    }

    componentWillReceiveProps(newProps) {    
        console.log('Component WILL RECIEVE PROPS!')
    }

    shouldComponentUpdate(newProps, newState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {
        console.log('Component WILL UPDATE!');
    }

    componentDidUpdate(prevProps, prevState) {
        console.log('Component DID UPDATE!')
    }

    componentWillUnmount() {
        console.log('Component WILL UNMOUNT!')
    }
	
    render() {
        var validationMsg={
            display: this.state.invalid ? 'block' : 'none'
        };
        return (
            <div>
                <h3>{this.props.myNumber}</h3>
                <input type = "text" value = {this.state.data} onChange = {this.updateState} onBlur={this.validate} /><br />
                <div style={validationMsg}>Please enter something above!</div>
                <h3>{this.state.data}</h3>
                <h4>{Math.random()}</h4>

                {/*<input type = "text" value = {this.props.myDataProp} onChange = {this.props.updateStateProp} />
                <h3>{this.props.myDataProp}</h3>*/}
            </div>
        );
    }
}


class StaticContent extends React.Component {
    constructor() {
        super();
    };
	
    render() {
        return (
            <div>
                <h4>{Math.random()}</h4>
            </div>
        );
    }
}

ReactDOM.render(<div><App /><StaticContent /></div>, document.getElementById("app"));
//setTimeout(() => {ReactDOM.unmountComponentAtNode(document.getElementById('app'));}, 10000);
