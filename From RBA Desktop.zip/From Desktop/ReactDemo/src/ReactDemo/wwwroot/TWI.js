﻿import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter, BrowserRouter, Switch, Redirect, Route, NavLink as Link, browserHistory  } from 'react-router-dom';
import style from "./css/site.css";
import { Button, Modal, OverlayTrigger, Popover, Tooltip } from 'react-bootstrap';
import styled, { css } from 'styled-components';

import {CommentBox} from "./components/CommentBox"

class App extends React.Component {
    constructor(){
        super();
    }

    render(){
        var Menu=[{to: "/home", text: "Home"}, {to: "/about", text: "About"}, {to: "/ConTact", text: "Contact" }, {to: "", text: "What's this?!!", disabled: true}];
        return (
            <div>
                <Nav menu={Menu} />
                <Main />
            </div>
            );
    }
}
//App.contextTypes = {
//    router: React.PropTypes.object
//};

class Nav extends React.Component{
    //constructor({param}){
    constructor(){
        super();
        //this.param = param;
        this.state={navLink: 'nav-link', activeIndex: 0};
        this.handleMenuClick=this.handleMenuClick.bind(this);
    }

    handleMenuClick(e) {
        var index = e.target.getAttribute('data-key');
        if(this.state.activeIndex == index)
            e.preventDefault();
        else{
            this.setState((prevState, props)=>({activeIndex: index}));
            console.log(this.state.activeIndex);
        }
    }

    render(){
        var activeIndex = this.state.activeIndex;
        return (<header>
          <nav><ul className='nav nav-pills'>
            {
                this.props.menu.map((menu, index) => (
                    <MenuItem key={index.toString()} menu={menu} index={index} activeIndex={activeIndex} handleMenuClick={this.handleMenuClick} />
                ))
            }
        </ul></nav>
        </header>);
    }
}

//{menu, index, activeIndex, handleMenuClick}
//        <Link onClick={(props.menu.disabled)?null:props.handleMenuClick} to={{ pathname: props.menu.to, query: props.param }} className={`nav-link ${(props.menu.disabled)?'disabled':(props.activeIndex==props.index)? 'active': ''}`} data-key={props.index}>{props.menu.text}</Link>
var MenuItem = (props) => (
    <li className='nav-item'>
        <Link onClick={(props.menu.disabled)?null:props.handleMenuClick} to={{ pathname: props.menu.to, query: props.param }} className={`nav-link ${(props.menu.disabled)?'disabled':''}`} activeClassName={`${(props.menu.disabled)?'':'active'}`} data-key={props.index}>{props.menu.text}</Link>
    </li>
);
//
const Main = () => (
    <main>
        <Switch>
            <Redirect exact from="/" to="/home" />
            <Route path = '/home' component = {Home} urlParam="Venkat" />
            <Route path = '/about' component = {About} />
            <Route path = '/contact' component = {Contact} />
        </Switch>
    </main>
);

class Home extends React.Component{
    constructor(props/*,{match}*/){
        super(props);
        this.match=props.match;
        console.log(`Home => ${JSON.stringify(this.match)}`);

        this.props=props;
        this.props.Name="Venkat";
        this.props.Age=37;
        console.log(`Home => ${JSON.stringify(this.props)}`);

        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.callFromChild = this.callFromChild.bind(this);

        this.state={show: false, showDialog: false};
    }

    handleClose() {
        this.setState({ showDialog: false });
    }
    handleShow() {
        this.setState({ showDialog: true });
    }

    callFromChild(){
        alert("called...");
    }
        
    componentWillMount() {
        console.log('Component WILL MOUNT!')
        }

    componentDidMount() {
        console.log('Component DID MOUNT!')
        }

    componentWillReceiveProps(newProps) {    
        console.log('Component WILL RECIEVE PROPS!')
        }

    shouldComponentUpdate(newProps, newState) {
        return true;
        }

    componentWillUpdate(nextProps, nextState) {
        console.log('Component WILL UPDATE!');
        }

    componentDidUpdate(prevProps, prevState) {
        console.log('Component DID UPDATE!')
        }

    componentWillUnmount() {
        console.log('Component WILL UNMOUNT!')
        }

    componentDidMount() {
        console.log("componentDidMount()");
        setTimeout(() => this.setState({show: true}), 1);
    }

    render(){
        const popover = (
            <Popover id="modal-popover" title="popover">
                very popover. such engagement
            </Popover>
        );
        const tooltip = <Tooltip id="modal-tooltip">wow.</Tooltip>;

        var Menu=[{to: '/home/', text: "Payment"}, {to: `${this.match.url}/payees`, text: "Payees"}, {to: `/home/billers`, text: "Billers" }, {to: `${this.match.url}`, text: "What's this?!!", disabled: true}];

        console.dir("render()=>"+JSON.stringify(this.props));

var StyledButton = styled.button`
  border-radius: 3px;
  padding: 0.25em 1em;
  margin: 0 1em;
  background: transparent;
  color: palevioletred;
  border: 2px solid palevioletred;

  ${props => props.name && css`
    background: palevioletred;
    color: white;
  `}
  `;

  var ColSpanDiv = styled('div')`
background:lightseagreen;
grid-column:1/span 2;
grid-row:1
    -ms-grid-column: 1;
  -ms-grid-column-span: 3;
  -ms-grid-row: 1;
  `;
  var RowSpanDiv = styled('div')`
background:lightseagreen;
grid-column:2;
grid-row:1/span 2
        -ms-grid-column: 3;
        -ms-grid-row: 1;
        -ms-grid-row-span: 3;
    `;
  var Cell=styled('div')`
    background:lightseagreen;

-ms-grid-column: ${props => props.col};
-ms-grid-row: ${props => props.row};
`;

var Grid=styled('div')`
background:beige;
display:grid;
grid-template-columns:1fr 2fr 1fr;
grid-template-rows:100px 100px;
grid-auto-rows:100px;
grid-gap:10px 10px;

display: -ms-grid;
-ms-grid-columns: 1fr 10px 2fr 10px 1fr;
-ms-grid-rows: 100px 10px 100px;
`;

        return (
            <section className={`red-border ${(this.state.show)?'':'open'}`}>
                <h2>Home</h2>
                <Test {...this.props} />

            <StyledButton>I am a styled-button</StyledButton>
            <StyledButton name>I am a named styled-button</StyledButton>

            <Grid><ColSpanDiv>Item 1</ColSpanDiv><RowSpanDiv>Item 2</RowSpanDiv><Cell col={5} row={1}>Item 3</Cell><Cell col={1} row={3}>Item 4</Cell></Grid>

                <Button bsStyle="primary" bsSize="large" onClick={this.handleShow}>Launch demo modal</Button>
                <Modal show={this.state.showDialog} onHide={this.handleClose}>
                    <Modal.Header>
                        <Modal.Title>Modal heading</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <h4>Text in a modal</h4>
                        <p>Duis mollis, est non commodo luctus, nisi erat porttitor ligula.</p>

                        <h4>Popover in a modal</h4>
                        <p>there is a{' '}<OverlayTrigger overlay={popover}><a href="#popover">popover</a></OverlayTrigger>{' '}here</p>

                        <h4>Tooltips in a modal</h4>
                        <p>there is a{' '}<OverlayTrigger overlay={tooltip}><a href="#tooltip">tooltip</a></OverlayTrigger>{' '}here</p>

                        <hr />

                        <h4>Overflowing text to show scroll behavior</h4>
                        <p>
                          Cras mattis consectetur purus sit amet fermentum. Cras justo odio,
                          dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta
                          ac consectetur ac, vestibulum at eros.
                        </p>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={this.handleClose}>Close</Button>
                    </Modal.Footer>
                </Modal>

                {this.props.location.search.indexOf("true") > -1=="true" ? <button>This is a text</button>: null} <br />
                <Nav menu={Menu} />
		        <Route exact path="/home/" component = {Payment} />
		        <Route path = '/home/payees' render={() => { return (<Payee {...this.props} from="Home" callParentMethod={this.callFromChild} />);}} />
		        <Route path = '/home/billers' component = {Biller} />                
            </section>
        )
    }
}

export class Payee extends React.Component {
    constructor(props){
        super(props);
        this.props=props;
        console.log(`Payee => ${JSON.stringify(this.props)}`);
    }
    render() {
        return (
            <div>
                <h4>Payee...</h4>
                <h6>{this.props.from}</h6>
                <h6>{this.props.children}</h6>
                <button onClick={this.props.callParentMethod}>Click Me!</button>
           </div>
        );
    }
}
const Payment = () => ( <h3>Payment</h3> );
//const Payee = () => ( <h3>Payee</h3> );
const Biller = () => ( <h3>Biller</h3> );
const Test = (props) => ( <h3>{props.Name}</h3> );

class About extends React.Component{
    constructor({match}){
        super();
        this.match=match;
        console.log(this.props);
        console.log(this.match);
    }
    render(){
        var Menu=[{to: `${this.match.url}`, text: "Payment"}, {to: `${this.match.url}/payees`, text: "Payees"}, {to: `${this.match.url}/billers`, text: "Billers" }, {to: `${this.match.url}`, text: "What's this?!!", disabled: true}];
        return (
            <section>
                <h2>About</h2>
        {this.props.location.query=="true" ? <button>This is a text</button>: null} <br />
                <Nav menu={Menu} />
                <Route exact path = '/about/' component = {Payment} />
                <Route path = '/about/payees' component = {Payee} />
                <Route path = '/about/billers' component = {Biller} />
            </section>
        )
    }
}

class Contact extends React.Component{
    render(){
        return <div><h2>Contact</h2><CommentBox url="/api/values" /></div>
    }
}

ReactDOM.render((<HashRouter>
        <App />
    </HashRouter>), document.getElementById('app'));

////Below code is to prove that inheritance works in React, although defeats the purpose of Composition & Web-Components
//class T1 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T1=>${JSON.stringify(this.props)}`);
//    }
//    render(){
//        return <div><h2>T1{this.props.name}</h2></div>
//    }
//}
//class T2 extends T1{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T2=>${JSON.stringify(this.props)}`);
//    }
//    render(){
//        return <div>{super.render()}<h2>T2{this.props.name}</h2></div>;
//    }
//}
//ReactDOM.render((<HashRouter>
//        <T2 name="Venkat" />
//    </HashRouter>), document.getElementById('app'));

////Below code is for props.children to render child components
//class T1 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T1=>${JSON.stringify(this.props)}`);
//}
//    render(){
//        return <div><h2>T1{this.props.name}</h2><h3>{this.props.children}</h3></div>
//}
//}
//class T2 extends React.Component{
//    constructor(props){
//        super(props);
//        this.props=props;
//        console.log(`T2=>${JSON.stringify(this.props)}`);
//}
//    render(){
//        return <div><h2>T2{this.props.name}</h2></div>;
//}
//}
//ReactDOM.render((<HashRouter>
//        <T1 name="Venkat"><T2 name="Iyer" /></T1>
//    </HashRouter>), document.getElementById('app'));