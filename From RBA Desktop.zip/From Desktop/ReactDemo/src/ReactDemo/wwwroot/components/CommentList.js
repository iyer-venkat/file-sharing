﻿import React from 'react';
import {Comment} from './Comment';

export class CommentList extends React.Component{
    render() {
        var commentNodes = this.props.data.map(function(comment) {
            return (
              <Comment author={comment.Author} key={comment.Id}>
                {comment.Text}
              </Comment>
            );
        });
        return <div className="commentList">
            {commentNodes}
      </div>;
    }
}
/*
<Comment author="Daniel Lo Nigro">Hello ReactJS.NET World!</Comment>
<Comment author="Pete Hunt">This is one comment</Comment>
<Comment author="Jordan Walke">This is *another* comment</Comment>
*/