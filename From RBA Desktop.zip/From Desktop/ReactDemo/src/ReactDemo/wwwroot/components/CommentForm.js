﻿import React from 'react';

export class CommentForm extends React.Component{
    constructor(props){
        super(props);
        this.state = {toggleInput: "none"};
	this.showHideInput = this.showHideInput.bind(this);
    }
    showHideInput(){
        this.setState({toggleInput: (this.state.toggleInput=="none")?"block":"none"});
    }
    render() {
        return (<div className="commentForm">
        Hello, world! I am a CommentForm.
        <input style={{display: this.state.toggleInput}} />
        <button onClick={this.showHideInput}>Click Me!</button>
      </div>);
}
}